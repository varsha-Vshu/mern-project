const express = require("express");
const router = express.Router();

// Define a route on this router to serve a file
router.get("/doc", (req, res) => {
  // Send a file as a response
  const filePath = "./doc.txt"; // Replace with the actual file path
  res.sendFile(filePath, { root: __dirname });
});

module.exports = router;
