const express = require("express");
const app = express();
const port = 3000;

// Import the router module
const routerModule = require("./routes");

// Use the router module for a specific path
app.use("/example", routerModule);

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
