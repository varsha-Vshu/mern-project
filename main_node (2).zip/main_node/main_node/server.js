const express = require("express");
//const cookie = require("cookie-parser"); // Import the cookie package
const cookieParser = require("cookie-parser");

const app = express();
app.use(cookieParser());
app.get("/set-cookie", (req, res) => {
  res.cookie("user", "Jerry", { maxAge: 60000 }); // Example options
  res.send("Cookie has been set");
});
app.get("/get-cookie", (req, res) => {
  // Access the 'user' cookie value
  const userCookie = req.cookies.user;
  res.send(`User cookie value: ${userCookie}`);
});
app.get("/delete-cookie", (req, res) => {
  // Delete the 'user' cookie
  res.cookie("user", "", { maxAge: 0 });
  res.send("Cookie has been deleted");
});
app.listen(3000, () => {
  console.log("listening");
});
